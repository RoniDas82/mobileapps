package com.example.clgm.Interfaces;

import android.view.View;

public interface MenuClickListner {
        void onClicked(View view);
}
